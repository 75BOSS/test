// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCuN5zSA8rMekut6Hwm6MbZHqU72LEGokk",
  authDomain: "proyectocriss-e423e.firebaseapp.com",
  projectId: "proyectocriss-e423e",
  storageBucket: "proyectocriss-e423e.appspot.com",
  messagingSenderId: "134989009875",
  appId: "1:134989009875:web:d3180fb747f43fd1645526",
  measurementId: "G-3GJEXC15V5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Function to add a comment to Firestore
async function addComment(name, email, message) {
  try {
    const docRef = await addDoc(collection(db, "comments"), {
      name: name,
      email: email,
      message: message,
      timestamp: new Date()
    });
    console.log("Document written with ID: ", docRef.id);
    return true;
  } catch (error) {
    console.error("Error adding document: ", error);
    return false;
  }
}

// Form submission handler
document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('contactForm');
  form.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const name = document.getElementById('contact_form_name').value;
    const email = document.getElementById('contact_form_email').value;
    const message = document.getElementById('contact_form_message').value;
    
    // Show loading indicator
    Swal.fire({
      title: 'Sending...',
      text: 'Please wait while we send your message.',
      allowOutsideClick: false,
      showConfirmButton: false,
      willOpen: () => {
        Swal.showLoading();
      }
    });
    
    const success = await addComment(name, email, message);
    
    if (success) {
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Your message has been sent successfully.',
        confirmButtonColor: '#3085d6'
      });
      form.reset();
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'There was an error sending your message. Please try again.',
        confirmButtonColor: '#d33'
      });
    }
  });
});