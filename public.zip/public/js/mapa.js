
const key = 'lWJeJrbPxQJQKaLlqvqb';
const attributions =
	'<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> ' +
	'<a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>';

const roadLayer = new ol.layer.Tile({
	source: new ol.source.XYZ({
		attributions: attributions,
		url: 'https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=' + key,
		tileSize: 512,
		maxZoom: 22,
	}),
});

const aerialLayer = new ol.layer.Tile({
	source: new ol.source.XYZ({
		attributions: attributions,
		url: 'https://api.maptiler.com/maps/satellite/{z}/{x}/{y}.jpg?key=' + key,
		tileSize: 512,
		maxZoom: 20,
	}),
});

// Coordenadas originales
const originalLongitude = -78.649783;
const originalLatitude = -1.667028;


const adjustedLongitude = originalLongitude - 0.000018 * 2;
const adjustedLatitude = originalLatitude;

const view = new ol.View({
	center: ol.proj.fromLonLat([adjustedLongitude, adjustedLatitude]),
	zoom: 13,
});

const iconFeature = new ol.Feature({
	geometry: new ol.geom.Point(ol.proj.fromLonLat([adjustedLongitude, adjustedLatitude])),
});

const iconStyle = new ol.style.Style({
	image: new ol.style.Icon({
		anchor: [0.5, 1],
		anchorXUnits: 'fraction',
		anchorYUnits: 'fraction',
		src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="%23007bff"><path d="M12 0C8.139 0 5 3.139 5 7c0 3.41 2.459 7.3 6.761 11.727l.274.273a.75.75 0 0 0 1.073 0l.274-.273C16.541 14.3 19 10.41 19 7c0-3.861-3.139-7-7-7zm0 10a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"></path></svg>',
		scale: 2, // Escala del icono (0.5 significa la mitad del tamaño original)
	})
});

iconFeature.setStyle(iconStyle);

const vectorSource = new ol.source.Vector({
	features: [iconFeature]
});

const vectorLayer = new ol.layer.Vector({
	source: vectorSource
});

const map = new ol.Map({
	target: 'map',
	layers: [roadLayer, vectorLayer],
	view: view,
});

