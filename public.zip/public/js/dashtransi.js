$(document).ready(function () {
    $('#tablaPersonas').DataTable();

    $('#btnNuevo').click(function () {
        $('#formPersonas').trigger("reset");
        $('.modal-title').text("Nuevo Registro");
        $('#modalCRUD').modal('show');
    });

    // Mostrar la pantalla de bienvenida al cargar la página
    $('#welcome-screen').fadeIn(400);


    // Animación al presionar el enlace "Inicio"
    $('#home-link').click(function (e) {
        e.preventDefault(); // Prevenir el comportamiento predeterminado del enlace
        $('#main-content').hide();
        $('#citas-content').hide();
        $('#welcome-screen').fadeIn(400);
    });

    // Animación al presionar el enlace "Registro"
    $('#registro-link').click(function (e) {
        e.preventDefault(); // Prevenir el comportamiento predeterminado del enlace
        $('#main-content').fadeIn(400);
        $('#citas-content').hide();
        $('#welcome-screen').hide();
    });

    // Animación al presionar el enlace "Citas"
    $('#citas-link').click(function (e) {
        e.preventDefault(); // Prevenir el comportamiento predeterminado del enlace
        $('#main-content').hide();
        $('#citas-content').fadeIn(400);
        $('#welcome-screen').hide();
    });
});
