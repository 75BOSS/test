<?php
if (!empty($_POST['btnregistrar'])) {
    $usuario_id = intval($_POST['txtusuario_id']);
    $servicio_id = intval($_POST['txtservicio_id']); 
    $fecha_hora = $_POST['txtfecha'];
    $estado = $_POST['txtestado'];
    $notas = $_POST['txtnotas'];

    // Separar la fecha y la hora correctamente
    $fecha_hora_obj = new DateTime($fecha_hora);
    $fecha_solo = $fecha_hora_obj->format('Y-m-d');
    $hora_solo = $fecha_hora_obj->format('H:i:s');

    if (!empty($usuario_id) && !empty($servicio_id) && !empty($fecha_hora) && !empty($estado)) {
        $stmt = $conexion->prepare("INSERT INTO citas(usuario_id, servicio_id, fecha, hora, estado, notas) VALUES(?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('iissss', $usuario_id, $servicio_id, $fecha_solo, $hora_solo, $estado, $notas);
        
        if ($stmt->execute()) {
            echo "<script>
                Swal.fire({
                    title: 'Éxito',
                    text: 'Nueva cita registrada',
                    icon: 'success'
                }).then(function() {
                    location.reload();
                });
            </script>";
        } else {
            echo "<div class='alert alert-danger'>Error al registrar la cita: " . $stmt->error . "</div>";
        }
        $stmt->close();
    } else {
        echo "<div class='alert alert-danger'>Debe llenar todos los campos obligatorios</div>";
    }
}
?>
<script>
    window.history.replaceState(null, null, window.location.pathname);
</script>
