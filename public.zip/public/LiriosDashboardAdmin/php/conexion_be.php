<?php

$conexion = mysqli_connect("localhost", "root", "") or 
die ("Problemas en la conexión"); 

mysqli_select_db($conexion, "lcferreteria") or die
("Problemas al seleccionar la base de datos");

/*/
if ($conexion){
    echo "conectado";
}else{
        echo "no conectado";
}
*/

?>

