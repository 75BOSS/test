<?php

include 'conexion_be.php';

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
//$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
$password = $_POST['password'];
$rol = 'user'; // Rol por defecto

// Verificar que el correo no se repita en la base de datos
$verificar_correo = mysqli_query($conexion, "SELECT * FROM usuarios WHERE email = '$email'");

if (mysqli_num_rows($verificar_correo) > 0) {
    echo '
    <script>
        alert("Este correo ya está registrado, intenta con otro...");
        window.location = "../loginandregister.html";
    </script>
    ';
    exit();
}

$query = "INSERT INTO usuarios (nombre, apellido, telefono, email, password, rol)
          VALUES ('$nombre', '$apellido', '$telefono', '$email', '$password', '$rol')";

$ejecutar = mysqli_query($conexion, $query);

if ($ejecutar) {
    echo '
        <script>
            alert("Usuario almacenado exitosamente");
            window.location = "../loginandregister.html";
        </script>
    ';
} else {
    echo '
        <script>
            alert("Inténtalo de nuevo, usuario no almacenado");
            window.location = "../loginandregister.html";
        </script>
    ';
}

mysqli_close($conexion);

?>