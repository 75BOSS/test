<?php
session_start();

include 'conexion_be.php';

$email = $_POST['email'];
$password = $_POST['password'];

// Validar login
$validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE email='$email' and password='$password'");

if (mysqli_num_rows($validar_login) > 0) {
    $usuario = mysqli_fetch_assoc($validar_login);
    $_SESSION['id'] = $usuario['usuario_id'];
    $_SESSION['rol'] = $usuario['rol'];
    $_SESSION['nombre'] = $usuario['nombre'];
    $_SESSION['apellido'] = $usuario['apellido'];
    $_SESSION['usuario'] = $usuario['email'];

    // Mensaje de depuración
    echo "Rol: " . $_SESSION['rol'];

    if ($_SESSION['rol'] == 'admin') {
        header("Location: ../index.php");
    } elseif ($_SESSION['rol'] == 'user') {
        header("Location: ../../LiriosDashboardUser/indexuser.php");
    } else {
        // En caso de que haya otros roles no especificados
        echo '
        <script>
            alert("Rol no reconocido. Contacte al administrador.");
            window.location = "../loginandregister.html";
        </script>
        ';
    }
    exit;
} else {
    echo '
    <script>
        alert("Usuario inexistente o contraseña incorrecta, por favor verifique sus datos.");
        window.location = "../loginandregister.html";
    </script>
    ';
    exit;
}
?>