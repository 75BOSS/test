<?php
if (!empty($_GET["id"])) {
    $id = $_GET["id"];
    $eliminar = $conexion->query("DELETE FROM citas WHERE cita_id='$id'");
    
    if ($eliminar === TRUE) {
        echo "<script>
        Swal.fire({
            title: 'Éxito',
            text: 'Cita eliminada',
            icon: 'success'
        }).then(function() {
            location.reload();
        });
      </script>";
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar la cita: " . $conexion->error . "</div>";
    }
}
?>