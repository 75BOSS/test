<?php
if (!empty($_GET["id_servicio"])) {
    $id = $_GET["id_servicio"];
    $eliminar = $conexion->query("DELETE FROM servicios WHERE servicio_id='$id'");
    
    if ($eliminar === TRUE) {
        echo "<script>
                    Swal.fire({
                        title: 'Felicidades',
                        text: 'Servicio eliminado',
                        icon: 'success'
                    }).then(function() {
                        location.reload();
                    });
                  </script>";
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar el servicio: " . $conexion->error . "</div>";
    }
}
?>
<script>
    window.history.replaceState(null, null, window.location.pathname);
</script>