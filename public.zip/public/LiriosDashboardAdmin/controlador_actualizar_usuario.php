<?php
// Se reciben los datos del formulario mediante el método POST
if (!empty($_POST['btnmodificar'])) {
    $id = $_POST['txtid'];
    $nombre = $_POST['txtnombre'];
    $apellido = $_POST['txtapellido'];
    $email = $_POST['txtemail'];
    $telefono = $_POST['txttelefono'];
    $password = $_POST['txtpassword'];
    $rol = $_POST['txtrol'];

    // Se valida que todos los campos estén llenos
    if (!empty($nombre) && !empty($apellido) && !empty($email) && !empty($telefono) && !empty($password) && !empty($rol)) {
        // Se prepara la consulta para evitar inyecciones SQL
        $stmt = $conexion->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, email = ?, telefono = ?, password = ?, rol = ? WHERE usuario_id = ?");
        $stmt->bind_param('ssssssi', $nombre, $apellido, $email, $telefono, $password, $rol, $id);

        // Se ejecuta la consulta y se verifica si la actualización fue exitosa
        if ($stmt->execute()) {
            echo "<script>
                    Swal.fire({
                        title: 'Felicidades',
                        text: 'usuario actualizado',
                        icon: 'success'
                    }).then(function() {
                        location.reload(); // Recargar la página después de cerrar la alerta
                    });
                  </script>";
           
        } else {
            echo "<div class='alert alert-danger'>Error al modificar el usuario: " . $conexion->error . "</div>";
        }
        
        $stmt->close();
    } else {
        echo "<div class='alert alert-danger'>Faltan datos por llenar</div>";
    }

    // Se actualiza el historial del navegador para evitar que se reenvíen los datos al actualizar la página
    ?>
    <script>
        window.history.replaceState(null, null, window.location.pathname);
    </script>
    <?php
}
?>
