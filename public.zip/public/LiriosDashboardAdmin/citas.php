<?php
session_start();

include("conexion.php");
include("controlador_registrar_cita.php");
include("controlador_actualizar_cita.php");
include("controlador_eliminar_cita.php");

if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'admin'){
    echo '
        <script>
        alert("Acceso no autorizado. Debes iniciar sesión como administrador.");
        window.location = "loginandregister.php";
        </script>
    ';
    session_destroy();
    die();
}


?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/minilogo.jpeg">
    <title>Reservas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    
</head>

<body>
    
      
    <div id="main-wrapper">
        
        <header class="topbar" data-navbarbg="skin5">
                <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                    <div class="navbar-header" data-logobg="skin5">
                    
                        <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    
                        <a class="navbar-brand" href="index.php">
                        
                            <b class="logo-icon p-l-10">
                           
                            <img src="assets/images/logo1.jpg" alt="homepage" class="light-logo logo-style" 
                            style="margin-top: 5px; width: 65px; height: auto; border-radius: 15px;" />
                           
                        </b>
                        
                        <span class="logo-text">
                             
                        <img src="assets/images/logo3.png" alt="homepage" class="light-logo" width="150"
                        style="margin-top: 5px; width: 147px; height: auto; border-radius: 15px;" />
                            
                        </span>
                            
                        </a>
                        
                        <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                    </div>
                    
                    <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                        
                        <ul class="navbar-nav float-left mr-auto">
                            <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                            
                        </ul>
                        <ul style="margin-top: 15px;" >
                            <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="logout.php" 
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/cerrarsesion.png" alt="Cerrar sesión" 
                                    style="width: 35px; height: auto; margin-left: -10px;">
                            </a>                                
                            </li>
                        </ul>  
                    </div>
                </nav>
            </header>
            
            <aside class="left-sidebar" data-sidebarbg="skin5">
                <!-- Sidebar scroll-->
                <div class="scroll-sidebar">
                    <!-- Sidebar navigation-->
                    <nav class="sidebar-nav">
                        <ul id="sidebarnav" class="p-t-30">
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false"><i class="mdi mdi-home"></i><span class="hide-menu">Inicio</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="gestionusuarios.php" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">Gestor de usuarios</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="citas.php" aria-expanded="false"><i class="mdi mdi-blur-linear"></i><span class="hide-menu">Reservas</span></a></li>
                            <li class="sidebar-item"><a class="sidebar-link waves-effect waves-dark sidebar-link"href="servicios.php" class="sidebar-link"><i class="mdi mdi-multiplication-box"></i><span class="hide-menu"> Servicios </span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"class="comentarios waves-effect waves-dark sidebar-link" href="comentarios.php" aria-expanded="false"><i class="mdi mdi-relative-scale"></i><span class="hide-menu">Comentarios</span></a></li>
                        
                        </ul>
                    </nav>
                </div>
                
            </aside>
            
            
            <div class="page-wrapper" style="background-color: transparent ; height:100%">
            <video class="hero_slide_background" autoplay muted loop width="100%" height="100%"
            src="https://i.makeagif.com/media/1-12-2018/WG7Djs.mp4" preload="metadata"  
            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
            <!-- Añadir la pista de texto solo si es necesaria -->
            <track kind="metadata" label="cuepoints" data-removeondestroy="">
            Your browser does not support the video tag.
        </video>
            <div class="page-breadcrumb">
                <div class="row">
                <div class="col-12 d-flex no-block align-items-center" style="margin-top: 20px;">
                    <h4 class="page-title" style="color: #f0f0f0; font-weight: bold;">Reserve</h4>
                </div>

                </div>
            </div>
            <div class="container-fluid" style="100px">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4">Gestión de Citas</h5>
                                
                                <div class="mb-4 text-right">
                                    <button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal"
                                        data-target="#modalCRUD"><i class="fas fa-calendar-plus"></i> Nueva Reserva</button>
                                </div>

                                <!-- Modal de nueva cita -->
                                <div class="modal fade" id="modalCRUD" tabindex="-1" aria-labelledby="modalCRUDLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalCRUDLabel">Nueva Cita</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="" method="POST">
                                                    <div class="mb-3">
                                                        <label class="form-label">Usuario</label>
                                                        <select class="form-select" name="txtusuario_id">
                                                            <?php
                                                            $usuarios = $conexion->query("SELECT usuario_id, nombre, apellido FROM usuarios");
                                                            while ($usuario = $usuarios->fetch_object()) {
                                                                echo "<option value='{$usuario->usuario_id}'>{$usuario->nombre} {$usuario->apellido}</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label">Servicio</label>
                                                        <select class="form-select" name="txtservicio_id">
                                                            <?php
                                                            $servicios = $conexion->query("SELECT servicio_id, nombre FROM servicios");
                                                            while ($servicio = $servicios->fetch_object()) {
                                                                echo "<option value='{$servicio->servicio_id}'>{$servicio->nombre}</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label">Fecha y Hora</label>
                                                        <input type="datetime-local" class="form-control" name="txtfecha">
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label">Estado</label>
                                                        <select class="form-select" name="txtestado">
                                                            <option value="Pendiente">Pendiente</option>
                                                            <option value="Confirmada">Confirmada</option>
                                                            <option value="Cancelada">Cancelada</option>
                                                            <option value="Completada">Completada</option>
                                                        </select>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label">Notas</label>
                                                        <textarea class="form-control" name="txtnotas"></textarea>
                                                    </div>

                                                    <div class="mb-3">
                                                        <button type="submit" name="btnregistrar" value="Ok" class="btn btn-primary">Registrar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tabla de Citas -->
                                <div class="table-responsive">
                                    <table id="tablaCitas" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Usuario</th>
                                            <th>Servicio</th>
                                            <th>Fecha</th> <!-- Columna separada para fecha -->
                                            <th>Hora</th>  <!-- Nueva columna para hora -->
                                            <th>Estado</th>
                                            <th>Notas</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                        <tbody>
                                            <?php
                                            $citas = $conexion->query("SELECT c.*, u.nombre AS nombre_usuario, u.apellido AS apellido_usuario, s.nombre AS nombre_servicio 
                                                                        FROM citas c 
                                                                        JOIN usuarios u ON c.usuario_id = u.usuario_id 
                                                                        JOIN servicios s ON c.servicio_id = s.servicio_id");
                                            
                                            while ($datos = $citas->fetch_object()) { 
                                                // Formatear la hora correctamente
                                                $hora = new DateTime($datos->hora);
                                            ?>
                                                <tr>
                                                    <td><?= $datos->cita_id ?></td>
                                                    <td><?= $datos->nombre_usuario . ' ' . $datos->apellido_usuario ?></td>
                                                    <td><?= $datos->nombre_servicio ?></td>
                                                    <td><?= $datos->fecha ?></td>
                                                    <td><?= $hora->format('H:i') ?></td>
                                                    <td><?= $datos->estado ?></td>
                                                    <td><?= $datos->notas ?></td>
                                                    <td>
                                                        <a href="" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal<?= $datos->cita_id ?>">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="?id=<?= $datos->cita_id ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que quieres eliminar esta cita?')">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </a>
                                                    </td>
                                                </tr>

                                                <!-- Modal de modificación -->
                                                <div class="modal fade" id="exampleModal<?= $datos->cita_id ?>" tabindex="-1" aria-labelledby="exampleModalLabel<?= $datos->cita_id ?>" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h1 class="modal-title fs-5" id="exampleModalLabel<?= $datos->cita_id ?>">Modificar Cita</h1>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form action="" method="POST">
                                                                    <input type="hidden" value="<?= $datos->cita_id ?>" name="txtid">
                                                                    
                                                                    <div class="mb-3">
                                                                        <label class="form-label">Usuario</label>
                                                                        <select class="form-select" name="txtusuario_id">
                                                                            <?php
                                                                            $usuarios = $conexion->query("SELECT usuario_id, nombre, apellido FROM usuarios");
                                                                            while ($usuario = $usuarios->fetch_object()) {
                                                                                $selected = ($usuario->usuario_id == $datos->usuario_id) ? 'selected' : '';
                                                                                echo "<option value='{$usuario->usuario_id}' {$selected}>{$usuario->nombre} {$usuario->apellido}</option>";
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <label class="form-label">Servicio</label>
                                                                        <select class="form-select" name="txtservicio_id">
                                                                            <?php
                                                                            $servicios = $conexion->query("SELECT servicio_id, nombre FROM servicios");
                                                                            while ($servicio = $servicios->fetch_object()) {
                                                                                $selected = ($servicio->servicio_id == $datos->servicio_id) ? 'selected' : '';
                                                                                echo "<option value='{$servicio->servicio_id}' {$selected}>{$servicio->nombre}</option>";
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <label class="form-label">Fecha y Hora</label>
                                                                        <input type="datetime-local" class="form-control" name="txtfecha" value="<?= date('Y-m-d\TH:i', strtotime($datos->fecha)) ?>">
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <label class="form-label">Estado</label>
                                                                        <select class="form-select" name="txtestado">
                                                                            <option value="Pendiente" <?= $datos->estado == 'Pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                                                            <option value="Confirmada" <?= $datos->estado == 'Confirmada' ? 'selected' : '' ?>>Confirmada</option>
                                                                            <option value="Cancelada" <?= $datos->estado == 'Cancelada' ? 'selected' : '' ?>>Cancelada</option>
                                                                            <option value="Completada" <?= $datos->estado == 'Completada' ? 'selected' : '' ?>>Completada</option>
                                                                        </select>
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <label class="form-label">Notas</label>
                                                                        <textarea class="form-control" name="txtnotas"><?= $datos->notas ?></textarea>
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <button type="submit" name="btnmodificar" value="Ok" class="btn btn-primary">Modificar</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       
    </div>
    
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap Bundle JS (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
    <!-- Custom JS -->
    <script src="dist/js/custom.min.js"></script>
    <script src="dist/js/sidebarmenu.js"></script>
    
   <script>
$(document).ready(function() {
    // Inicializar DataTable
    $('#tablaCitas').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
        }
    });

    // Manejar el clic en el botón "Nueva Cita"
    $('#btnNuevo').on('click', function() {
        var myModal = new bootstrap.Modal(document.getElementById('modalCRUD'));
        myModal.show();
    });

    // Manejar el cierre de los modales
    $('.modal').on('hidden.bs.modal', function () {
        $('body').removeClass('modal-open');
        $('.modal-backdrop').remove();
    });

    // Manejar el clic en los botones de editar
    $('[data-toggle="modal"]').on('click', function(e) {
        e.preventDefault();
        var targetModal = $(this).data('target');
        var myModal = new bootstrap.Modal(document.querySelector(targetModal));
        myModal.show();
    });
});
</script>
       
</body>

</html>