<?php
session_start();
include 'conexion.php';

$id_usuario = $_SESSION['id'];

$sql = "SELECT * FROM Citas WHERE usuario_id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

$events = array();
while ($row = $result->fetch_assoc()) {
    $events[] = array(
        'title' => $row['servicios'],
        'start' => $row['fecha']
    );
}

echo json_encode($events);
?>
