<?php
if (isset($_POST['btnmodificarservicio'])) {
    $id = $_POST['txtid'];
    $nombre = $_POST['txtnombre'];
    $descripcion = $_POST['txtdescripcion'];
    $duracion = $_POST['txtduracion'];
    $precio = $_POST['txtprecio'];
    

    if (!empty($nombre) && !empty($descripcion) && !empty($duracion) && !empty($precio)) {
        if (!empty($_FILES['txtimagen']['name'])) {
            $imagen = file_get_contents($_FILES['txtimagen']['tmp_name']);
            $stmt = $conexion->prepare("UPDATE servicios SET nombre = ?, descripcion = ?, duracion = ?, precio = ?, imagen = ? WHERE servicio_id = ?");
            $null = NULL;
            $stmt->bind_param("ssidbi", $nombre, $descripcion, $duracion, $precio, $null, $id);
            $stmt->send_long_data(4, $imagen);
        } else {
            $stmt = $conexion->prepare("UPDATE servicios SET nombre = ?, descripcion = ?, duracion = ?, precio = ? WHERE servicio_id = ?");
            $stmt->bind_param("ssidi", $nombre, $descripcion, $duracion, $precio, $id);
        }

        if ($stmt->execute()) {
            //echo "<script>alert('Servicio actualizado correctamente');</script>";
        } else {
            echo "<script>alert('Error al modificar el servicio: " . $stmt->error . "');</script>";
        }
        
        $stmt->close();
    } else {
        echo "<script>alert('Faltan datos por llenar');</script>";
    }
}
?>
<script>
    window.history.replaceState(null, null, window.location.pathname);
</script>