<?php
if (!empty($_POST['btnmodificar'])) {
    $id = $_POST['txtid'];
    $usuario_id = $_POST['txtusuario_id'];
    $servicio_id = $_POST['txtservicio_id'];
    $fecha_hora = $_POST['txtfecha'];
    $estado = $_POST['txtestado'];
    $notas = $_POST['txtnotas'];

    // Crear objeto DateTime desde el input datetime-local
    $fecha_hora_obj = new DateTime($fecha_hora);
    
    // Formatear la fecha y hora por separado
    $fecha_solo = $fecha_hora_obj->format('Y-m-d');
    $hora_solo = $fecha_hora_obj->format('H:i:s');

    if (!empty($usuario_id) && !empty($servicio_id) && !empty($fecha_hora) && !empty($estado)) {
        // Modificar la consulta para actualizar tanto fecha como hora
        $stmt = $conexion->prepare("UPDATE citas SET usuario_id = ?, servicio_id = ?, fecha = ?, hora = ?, estado = ?, notas = ? WHERE cita_id = ?");
        $stmt->bind_param('iissssi', $usuario_id, $servicio_id, $fecha_solo, $hora_solo, $estado, $notas, $id);

        if ($stmt->execute()) {
            echo "<script>
            Swal.fire({
                title: 'Éxito',
                text: 'Cita actualizada correctamente',
                icon: 'success'
            }).then(function() {
                location.reload();
            });
            </script>";
        } else {
            echo "<div class='alert alert-danger'>Error al modificar la cita: " . $conexion->error . "</div>";
        }
        
        $stmt->close();
    } else {
        echo "<div class='alert alert-danger'>Faltan datos obligatorios por llenar</div>";
    }
}
?>