<?php
session_start();
include "conexion.php";

// Verificar si se recibe un ID válido
if (isset($_GET["id"]) && is_numeric($_GET["id"])) {
    $id = intval($_GET["id"]); // Convertir el ID a entero

    // Preparar la consulta para eliminar el comentario
    $stmt = $conexion->prepare("DELETE FROM Comentarios WHERE comentario_id = ?");
    if ($stmt === false) {
        // Si hay un error al preparar la consulta, mostrar un mensaje de error
        die('Error al preparar la consulta');
    }

    // Vincular el parámetro y ejecutar la consulta
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        // Si la eliminación fue exitosa, redirigir al usuario de vuelta a la página de comentarios
        header("Location: comentarios.php");
        exit;
    } else {
        // Si hubo un error al ejecutar la consulta, mostrar un mensaje de error
        die('Error al eliminar el comentario');
    }

    // Cerrar la declaración
    $stmt->close();
} else {
    // Si no se proporcionó un ID válido, mostrar un mensaje de error
    die('ID de comentario no válido');
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>