<?php
session_start();

include("conexion.php");
include("controlador_registrar_servicio.php");
include("controlador_actualizar_servicio.php");
include("controlador_eliminar_servicio.php");

if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'admin'){
    echo '
        <script>
        alert("Acceso no autorizado. Debes iniciar sesión como administrador.");
        window.location = "loginandregister.php";
        </script>
    ';
    session_destroy();
    die();
}


?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/minilogo.jpeg">
    <title>Servicios</title>
    <!-- Custom CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    
</head>

<body>
    
      
    <div id="main-wrapper">
        
        <header class="topbar" data-navbarbg="skin5">
                <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                    <div class="navbar-header" data-logobg="skin5">
                    
                        <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    
                        <a class="navbar-brand" href="index.html">
                        
                            <b class="logo-icon p-l-10">
                           
                            <img src="assets/images/logo1.jpg" alt="homepage" class="light-logo logo-style" 
                            style="margin-top: 5px; width: 65px; height: auto; border-radius: 15px;" />
                           
                            </b>
                            
                            <span class="logo-text">
                                
                            <img src="assets/images/logo3.png" alt="homepage" class="light-logo" width="150"
                            style="margin-top: 5px; width: 147px; height: auto; border-radius: 15px;" />
                                
                            </span>
                            
                        </a>
                        
                        <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                    </div>
                    
                    <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                        
                        <ul class="navbar-nav float-left mr-auto">
                            <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                            
                        </ul>
                        <ul style="margin-top: 15px;" >
                            <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="logout.php" 
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/cerrarsesion.png" alt="Cerrar sesión" 
                                    style="width: 35px; height: auto; margin-left: -10px;">
                            </a>
                                    
                            </li>
                        </ul>
                        
                                            
                            
                        
                    </div>
                </nav>
            </header>
            
            <aside class="left-sidebar" data-sidebarbg="skin5">
                <!-- Sidebar scroll-->
                <div class="scroll-sidebar">
                    <!-- Sidebar navigation-->
                    <nav class="sidebar-nav">
                        <ul id="sidebarnav" class="p-t-30">
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false"><i class="mdi mdi-home"></i><span class="hide-menu">Inicio</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="gestionusuarios.php" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">Gestor de usuarios</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="citas.php" aria-expanded="false"><i class="mdi mdi-blur-linear"></i><span class="hide-menu">Reservas</span></a></li>
                            <li class="sidebar-item"><a class="sidebar-link waves-effect waves-dark sidebar-link"href="servicios.php" class="sidebar-link"><i class="mdi mdi-multiplication-box"></i><span class="hide-menu"> Servicios </span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"class="comentarios waves-effect waves-dark sidebar-link" href="comentarios.php" aria-expanded="false"><i class="mdi mdi-relative-scale"></i><span class="hide-menu">Comentarios</span></a></li>
                        
                        </ul>
                    </nav>
                </div>
                
            </aside>
            
            
            <div class="page-wrapper" style="background-color: transparent ;height:100%">
            <video class="hero_slide_background" autoplay muted loop width="100%" height="100%"
            src="https://i.makeagif.com/media/1-12-2018/WG7Djs.mp4" preload="metadata"  
            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
            <!-- Añadir la pista de texto solo si es necesaria -->
            <track kind="metadata" label="cuepoints" data-removeondestroy="">
            Your browser does not support the video tag.
        </video>
            <div class="page-breadcrumb">
                        <div class="row">
                        <div class="col-12 d-flex no-block align-items-center" style="margin-top: 18px;">
                            <h4 class="page-title" style="color: #f0f0f0; font-weight: bold;">Services</h4>
                        </div>
                        </div>
                    </div>
        <!--Containerfluid--> 
        <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title mb-4">Gestión de Servicios</h5>
                                        
                                        <div class="mb-4 text-right">
                                            <button id="btnNuevoServicio" type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCRUDServicio">
                                            <i class="fas fa-plus"></i> Nuevo Servicio</button>
                                        </div>
                    
                                        <!-- Modal de nuevo registro de servicio -->
                                        <div class="modal fade" id="modalCRUDServicio" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="nuevoServicioModalLabel">Registro de Servicio</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="" method="POST" enctype="multipart/form-data">
                                                            <div class="mb-3">
                                                                <label class="form-label">Nombre</label>
                                                                <input type="text" class="form-control" name="txtnombre">
                                                            </div>
                    
                                                            <div class="mb-3">
                                                                <label class="form-label">Descripción</label>
                                                                <textarea class="form-control" name="txtdescripcion"></textarea>
                                                            </div>
                    
                                                            <div class="mb-3">
                                                                <label class="form-label">Duración (minutos)</label>
                                                                <input type="number" class="form-control" name="txtduracion">
                                                            </div>
                    
                                                            <div class="mb-3">
                                                                <label class="form-label">Precio</label>
                                                                <input type="number" step="0.01" class="form-control" name="txtprecio">
                                                            </div>
                    
                                                            <div class="mb-3">
                                                                <label class="form-label">Imagen</label>
                                                                <input type="file" name="txtimagen" accept="image/*" required>
                                                            </div>
                    
                                                            <div class="mb-3">
                                                                <button type="submit" name="btnregistrarservicio" value="Ok" class="btn btn-primary">Registrar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                    
                                        <!-- Tabla de Servicios -->
                                        <div class="table-responsive">
                                            <table id="tablaServicios" class="table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Nombre</th>
                                                        <th>Descripción</th>
                                                        <th>Duración</th>
                                                        <th>Precio</th>
                                                        <th>Imagen</th>
                                                        <th>Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $servicios = $conexion->query("SELECT * FROM servicios");
                                                    while ($servicio = $servicios->fetch_object()) { ?>
                                                        <tr>
                                                            <td><?= $servicio->servicio_id ?></td>
                                                            <td><?= $servicio->nombre ?></td>
                                                            <td><?= $servicio->descripcion ?></td>
                                                            <td><?= $servicio->duracion ?></td>
                                                            <td><?= $servicio->precio ?></td>
                                                            <td>
                                                                <img src="data:image/jpeg;base64,<?= base64_encode($servicio->imagen) ?>" 
                                                                    alt="<?= $servicio->nombre ?>" width="50">
                                                            </td>
                                                            <td>
                                                               <a href="#" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalEditarServicio<?= $servicio->servicio_id ?>">
                                                                    <i class="fas fa-edit"></i>
                                                                </a>
                                                                <a href="?id_servicio=<?= $servicio->servicio_id ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que quieres eliminar este servicio?')">
                                                                    <i class="fas fa-trash-alt"></i>
                                                                </a>
                                                                
                                                            </td>
                                                        </tr>
                    
                                                    <!-- Modal de edición de servicio -->
                                                            <div class="modal fade" id="modalEditarServicio<?= $servicio->servicio_id ?>" tabindex="-1" aria-labelledby="editarServicioModalLabel<?= $servicio->servicio_id ?>" aria-hidden="true">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h1 class="modal-title fs-5" id="editarServicioModalLabel<?= $servicio->servicio_id ?>">Modificar Servicio</h1>
                                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <form action="" method="POST" enctype="multipart/form-data">
                                                                                <input type="hidden" name="txtid" value="<?= $servicio->servicio_id ?>">
                                                                                <div class="mb-3">
                                                                                    <label class="form-label">Nombre</label>
                                                                                    <input type="text" class="form-control" name="txtnombre" value="<?= $servicio->nombre ?>">
                                                                                </div>

                                                                                <div class="mb-3">
                                                                                    <label class="form-label">Descripción</label>
                                                                                    <textarea class="form-control" name="txtdescripcion"><?= $servicio->descripcion ?></textarea>
                                                                                </div>

                                                                                <div class="mb-3">
                                                                                    <label class="form-label">Duración (minutos)</label>
                                                                                    <input type="number" class="form-control" name="txtduracion" value="<?= $servicio->duracion ?>">
                                                                                </div>

                                                                                <div class="mb-3">
                                                                                    <label class="form-label">Precio</label>
                                                                                    <input type="number" step="0.01" class="form-control" name="txtprecio" value="<?= $servicio->precio ?>">
                                                                                </div>

                                                                                <div class="mb-3">
                                                                                    <label class="form-label">Imagen actual</label>
                                                                                    <img src="data:image/jpeg;base64,<?= base64_encode($servicio->imagen) ?>" 
                                                                                        alt="<?= $servicio->nombre ?>" width="100">
                                                                                </div>

                                                                                <div class="mb-3">
                                                                                    <label class="form-label">Nueva imagen (opcional)</label>
                                                                                    <input type="file" class="form-control" name="txtimagen">
                                                                                </div>

                                                                                <div class="mb-3">
                                                                                    <button type="submit" name="btnmodificarservicio" value="Ok" class="btn btn-primary">Modificar</button>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
       
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap Bundle JS (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
    <!-- Custom JS -->
    <script src="dist/js/custom.min.js"></script>
    <script src="dist/js/sidebarmenu.js"></script>
       <script>
    $(document).ready(function() {
        // Inicializar DataTable
        $('#tablaServicios').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
            }
        });

        // Manejar el clic en el botón "Nuevo"
        $('#btnNuevo').on('click', function() {
            var myModal = new bootstrap.Modal(document.getElementById('modalCRUD'));
            myModal.show();
        });

        // Manejar el cierre de los modales
        $('.modal').on('hidden.bs.modal', function () {
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
        });

        // Manejar el clic en los botones de editar
        $('[data-bs-toggle="modal"]').on('click', function(e) {
            e.preventDefault();
            var targetModal = $(this).data('bs-target');
            var myModal = new bootstrap.Modal(document.querySelector(targetModal));
            myModal.show();
        });
    });
    </script>
       
</body>

</html>