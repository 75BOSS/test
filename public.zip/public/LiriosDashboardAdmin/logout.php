<?php
	
	session_start();
	session_destroy();
	
	header("Location: loginandregister.html");
?><?php
	
	session_start();
	session_destroy();
	
	header("Location: loginandregister.html");
?>