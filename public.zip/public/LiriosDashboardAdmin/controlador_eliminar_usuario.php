<?php
if (!empty($_GET["id"])) {
    $id = $_GET["id"];
    $eliminar = $conexion->query("DELETE FROM usuarios WHERE usuario_id='$id'");
    
    if ($eliminar === TRUE) {
        echo "<script>
                    Swal.fire({
                        title: 'Felicidades',
                        text: 'usuario eliminado',
                        icon: 'success'
                    }).then(function() {
                        location.reload(); // Recargar la página después de cerrar la alerta
                    });
                  </script>";
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar el usuario: " . $conexion->error . "</div>";
    }
}
?>
<script>
    window.history.replaceState(null, null, window.location.pathname);
</script>
