<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'user') {
    header("Location: loginandregister.php");
    exit();
}

$id_usuario = $_SESSION['id'];
$nombre_usuario = $_SESSION['nombre'];
$email_usuario = $_SESSION['usuario'];

echo "ID de Usuario:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa " . $id_usuario . "<br>";
echo "Nombre de Usuario: " . $nombre_usuario . "<br>";
echo "Email de Usuario: " . $email_usuario . "<br>";
// Obtener citas próximas del usuario
$sql_citas = "SELECT Citas.*, Servicios.nombre AS servicio_nombre FROM Citas 
              INNER JOIN Servicios ON Citas.servicio_id = Servicios.servicio_id 
              WHERE usuario_id = ? AND fecha >= CURDATE() 
              ORDER BY fecha ASC";
$stmt = $conexion->prepare($sql_citas);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado_citas = $stmt->get_result();

// Obtener servicios disponibles
$sql_servicios = "SELECT * FROM Servicios";
$resultado_servicios = $conexion->query($sql_servicios);

?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>Dashboard de Usuario</title>
    <link href="assets/libs/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet" />
    <link href="assets/extra-libs/calendar/calendar.css" rel="stylesheet" />
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="dist/css/userstyles.css" rel="stylesheet">
    <style>
        .blue-highlight {
            background-color: #007bff;
            color: white !important;
        }
        .welcome-card {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .stat-card {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
    </style>
</head>

<body>
    <div id="main-wrapper">
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <a class="navbar-brand" href="index.html">
                        <b class="logo-icon p-l-10">
                            <img src="assets/images/logo-icon.png" alt="homepage" class="light-logo" />
                        </b>
                        <span class="logo-text">
                            <img src="assets/images/logo-text.png" alt="homepage" class="light-logo" />
                        </span>
                    </a>
                </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block">
                            <a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar">
                                <i class="mdi mdi-menu font-24"></i>
                            </a>
                        </li>
                    </ul>
                    <ul class="navbar-nav float-right">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/users/1.jpg" alt="user" class="rounded-circle" width="31">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                              
                                <a class="dropdown-item" href="javascript:void(0)"><i class="ti-settings m-r-5 m-l-5"></i> Configuración de Cuenta</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php"><i class="fa fa-power-off m-r-5 m-l-5"></i> Cerrar Sesión</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

         <aside class="left-sidebar" id="leftSidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                        <li class="sidebar-item blue-highlight">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="dashboard.php" aria-expanded="false">
                                <i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="citas.php" aria-expanded="false">
                                <i class="mdi mdi-calendar-check"></i><span class="hide-menu">Mis Citas</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="historial.php" aria-expanded="false">
                                <i class="mdi mdi-history"></i><span class="hide-menu">Historial</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="comentarios.php" aria-expanded="false">
                                <i class="mdi mdi-comment-text"></i><span class="hide-menu">Comentarios</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <div class="calendar-wrapper">
        <div class="calendar-container">
            <div class="today">
                <span class="today-label">HOY</span>
                <span class="today-date" id="todayDate"></span>
                <span class="today-month" id="todayMonth"></span>
            </div>
            <div class="calendar">
                <div class="nav-buttons">
                    <button class="nav-button" id="prevMonth">&lt;</button>
                    <h2 id="currentMonth"></h2>
                    <button class="nav-button" id="nextMonth">&gt;</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Dom</th>
                            <th>Lun</th>
                            <th>Mar</th>
                            <th>Mié</th>
                            <th>Jue</th>
                            <th>Vie</th>
                            <th>Sáb</th>
                        </tr>
                    </thead>
                    <tbody id="calendarBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- The Modal -->
    <div id="dateModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Seleccionar Fecha</h2>
                <span class="close" id="closeModal">&times;</span>
            </div>
            <div class="modal-body">
                <form id="dateForm">
                    <label for="selectedDate">Fecha:</label>
                    <input type="text" id="selectedDate" name="selectedDate" readonly>
                    <label for="selectedTime">Hora:</label>
                    <select id="selectedTime" name="selectedTime" required>
                        <option value="10:00">10:00 AM</option>
                        <option value="11:00">11:00 AM</option>
                        <option value="12:00">12:00 PM</option>
                        <option value="13:00">01:00 PM</option>
                        <option value="14:00">02:00 PM</option>
                        <option value="15:00">03:00 PM</option>
                        <option value="16:00">04:00 PM</option>
                        <option value="17:00">05:00 PM</option>
                    </select>
                    <label for="service">Servicio:</label>
                    <select id="service" name="service" required>
                        <option value="hidratacion">Hidratación - $50</option>
                        <option value="limpieza">Limpieza - $40</option>
                        <option value="inyeccion">Inyección - $60</option>
                        <option value="masaje">Masaje Facial - $45</option>
                        <option value="exfoliacion">Exfoliación - $35</option>
                        <option value="acido">Ácido Hialurónico - $55</option>
                        <option value="laser">Tratamiento Láser - $70</option>
                    </select>
                    <label for="price">Precio:</label>
                    <input type="text" id="price" name="price" readonly>
                    <div class="selected-date-time">
                        <p>Fecha y hora seleccionadas:</p>
                        <p id="selectedDateTime"></p>
                    </div>
                    <input type="submit" value="Reservar">
                </form>
            </div>
        </div>
    </div>
                
            </div>
           
        </div>
    </div>

    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/moment/min/moment.min.js"></script>
    <script src="assets/libs/fullcalendar/dist/fullcalendar.min.js"></script>  

    <script>
        $(document).ready(function() {
            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                events: [
                    <?php 
                    $resultado_citas->data_seek(0);  // Reset pointer to start
                    while($cita = $resultado_citas->fetch_assoc()): 
                    ?>
                    {
                        title: '<?php echo addslashes($cita['servicio_nombre']); ?>',
                        start: '<?php echo $cita['fecha']; ?>',
                        status: '<?php echo $cita['estado']; ?>'
                    },
                    <?php endwhile; ?>
                ],
                editable: false
            });
        });
        const today = new Date();
        let currentMonth = today.getMonth();
        let currentYear = today.getFullYear();

        const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

        function updateCalendar() {
            const firstDay = new Date(currentYear, currentMonth, 1);
            const lastDay = new Date(currentYear, currentMonth + 1, 0);
            
            document.getElementById('currentMonth').textContent = `${monthNames[currentMonth]} ${currentYear}`;
            
            const calendarBody = document.getElementById('calendarBody');
            calendarBody.innerHTML = '';

            let date = 1;
            for (let i = 0; i < 6; i++) {
                const row = document.createElement('tr');
                for (let j = 0; j < 7; j++) {
                    if (i === 0 && j < firstDay.getDay()) {
                        const cell = document.createElement('td');
                        cell.classList.add('empty');
                        row.appendChild(cell);
                    } else if (date > lastDay.getDate()) {
                        break;
                    } else {
                        const cell = document.createElement('td');
                        cell.textContent = date;
                        if (date === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear()) {
                            cell.classList.add('today-highlight');
                        }
                        cell.addEventListener('click', (function(selectedDate) {
                            return function() {
                                openModal(selectedDate);
                            };
                        })(date));
                        row.appendChild(cell);
                        date++;
                    }
                }
                calendarBody.appendChild(row);
            }
        }

        function openModal(date) {
            document.getElementById("selectedDate").value = `${monthNames[currentMonth]} ${date}, ${currentYear}`;
            document.getElementById("selectedDateTime").textContent = `Fecha: ${monthNames[currentMonth]} ${date}, ${currentYear}`;
            document.getElementById("dateModal").style.display = "block";
            updateSelectedDateTime();
        }

        function closeModal() {
            document.getElementById("dateModal").style.display = "none";
        }

        document.getElementById('prevMonth').addEventListener('click', () => {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            updateCalendar();
        });

        document.getElementById('nextMonth').addEventListener('click', () => {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            updateCalendar();
        });

        document.getElementById('todayDate').textContent = today.getDate();
        document.getElementById('todayMonth').textContent = `${monthNames[today.getMonth()]} - ${today.getFullYear()}`;

        updateCalendar();

        // Modal close button event listener
        document.getElementById("closeModal").addEventListener('click', closeModal);

        // Close the modal if the user clicks outside of the modal
        window.addEventListener('click', function(event) {
            const modal = document.getElementById("dateModal");
            if (event.target === modal) {
                modal.style.display = "none";
            }
        });

        // Update price field based on selected service
        document.getElementById("service").addEventListener("change", function() {
            const selectedService = this.value;
            let price;
            switch (selectedService) {
                case "hidratacion":
                    price = "$50";
                    break;
                case "limpieza":
                    price = "$40";
                    break;
                case "inyeccion":
                    price = "$60";
                    break;
                case "masaje":
                    price = "$45";
                    break;
                case "exfoliacion":
                    price = "$35";
                    break;
                case "acido":
                    price = "$55";
                    break;
                case "laser":
                    price = "$70";
                    break;
                default:
                    price = "";
                    break;
            }
            document.getElementById("price").value = price;
            updateSelectedDateTime();
        });

        // Update the selected date and time text
        document.getElementById("selectedTime").addEventListener("change", updateSelectedDateTime);

        function updateSelectedDateTime() {
            const date = document.getElementById("selectedDate").value;
            const time = document.getElementById("selectedTime").value;
            document.getElementById("selectedDateTime").textContent = `Fecha y Hora: ${date} a las ${time}`;
        }

        // Initialize price field based on the default selected service
        document.getElementById("price").value = "$50"; // Valor inicial para el primer servicio
        updateSelectedDateTime();
    </script>
    <script>
document.addEventListener('DOMContentLoaded', function() {
    var toggleButton = document.querySelector('.sidebartoggler');
    var sidebar = document.getElementById('leftSidebar');
    var mainContent = document.querySelector('.page-wrapper');

    toggleButton.addEventListener('click', function(e) {
        e.preventDefault();
        sidebar.classList.toggle('mini-sidebar');
        mainContent.classList.toggle('mini-sidebar');
    });
});
</script>
    
</body>

</html>
