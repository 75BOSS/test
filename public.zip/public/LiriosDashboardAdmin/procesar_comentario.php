<?php

session_start();
include "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = filter_var(trim($_POST['contact_form_name']), FILTER_SANITIZE_STRING);
    $email = filter_var(trim($_POST['contact_form_email']), FILTER_SANITIZE_EMAIL);
    $mensaje = filter_var(trim($_POST['contact_form_message']), FILTER_SANITIZE_STRING);
    $fecha = date('Y-m-d H:i:s');
    
    // Validaciones básicas
    if (empty($nombre) || empty($email) || empty($mensaje)) {
        echo "<script>
            Swal.fire({
                title: 'Error',
                text: 'Todos los campos son requeridos',
                icon: 'error'
            });
        </script>";
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>
            Swal.fire({
                title: 'Error',
                text: 'Por favor ingrese un email válido',
                icon: 'error'
            });
        </script>";
        exit;
    }
    
    // Preparar la consulta
    $stmt = $conexion->prepare("INSERT INTO Comentarios (nombre, email, mensaje, fecha) VALUES (?, ?, ?, ?)");
    
    if ($stmt === false) {
        echo "<script>
            Swal.fire({
                title: 'Error',
                text: 'Error en la preparación de la consulta',
                icon: 'error'
            });
        </script>";
        exit;
    }
    
    $stmt->bind_param("ssss", $nombre, $email, $mensaje, $fecha);
    
    if ($stmt->execute()) {
        echo "<script>
            Swal.fire({
                title: '¡Éxito!',
                text: 'Comentario enviado correctamente',
                icon: 'success'
            }).then(() => {
                document.getElementById('contactForm').reset();
            });
        </script>";
    } else {
        echo "<script>
            Swal.fire({
                title: 'Error',
                text: 'Error al guardar el comentario',
                icon: 'error'
            });
        </script>";
    }
    
    $stmt->close();
}
$conexion->close();
?>