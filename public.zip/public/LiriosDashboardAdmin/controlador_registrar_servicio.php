<?php
if (isset($_POST['btnregistrarservicio'])) {
    $nombre = $_POST['txtnombre'];
    $descripcion = $_POST['txtdescripcion'];
    $duracion = $_POST['txtduracion'];
    $precio = $_POST['txtprecio'];

    if (!empty($nombre) && !empty($descripcion) && !empty($duracion) && !empty($precio) && isset($_FILES['txtimagen'])) {
        $imagen = file_get_contents($_FILES['txtimagen']['tmp_name']);
        if ($imagen !== false) {
            $stmt = $conexion->prepare("INSERT INTO servicios (nombre, descripcion, duracion, precio, imagen) VALUES (?, ?, ?, ?, ?)");
            $null = NULL;
            $stmt->bind_param("ssidb", $nombre, $descripcion, $duracion, $precio, $null);
            $stmt->send_long_data(4, $imagen);
            if ($stmt->execute()) {
                echo "<script>alert('Nuevo servicio registrado correctamente');</script>";
            } else {
                echo "<script>alert('Error al registrar el servicio: " . $stmt->error . "');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Error al procesar la imagen');</script>";
        }
    } else {
        echo "<script>alert('Debe llenar todos los campos y subir una imagen');</script>";
    }
}
?>
<script>
    window.history.replaceState(null, null, window.location.pathname);
</script>