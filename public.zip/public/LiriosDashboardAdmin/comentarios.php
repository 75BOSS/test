<?php
session_start(); // Iniciar sesión
include "conexion.php"; // Incluir la conexión a la base de datos

// Configuración de la paginación
$comentarios_por_pagina = 10; // Número de comentarios por página
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $comentarios_por_pagina;

// Obtener el total de comentarios
$total_comentarios = $conexion->query("SELECT COUNT(*) as total FROM Comentarios")->fetch_assoc()['total'];
$total_paginas = ceil($total_comentarios / $comentarios_por_pagina);

// Consulta para obtener los comentarios paginados
$query = "SELECT * FROM Comentarios ORDER BY fecha DESC LIMIT $inicio, $comentarios_por_pagina";
$resultado = $conexion->query($query);
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/minilogo.jpeg">
    <title>Comentarios</title>
    <!-- Custom CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
</head>

<body>
    <div id="main-wrapper">
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <a class="navbar-brand" href="index.php">
                        <img src="assets/images/logo1.jpg" alt="homepage" class="light-logo logo-style" style="margin-top: 5px; width: 65px; height: auto; border-radius: 15px;" />
                        <img src="assets/images/logo3.png" alt="homepage" class="light-logo" width="150" style="margin-top: 5px; width: 147px; height: auto; border-radius: 15px;" />
                    </a>
                </div>

                <!-- Botón de cerrar sesión -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block">
                            <a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar">
                                <i class="mdi mdi-menu font-24"></i>
                            </a>
                        </li>
                    </ul>
                    <ul style="margin-top: 15px;">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="logout.php" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/cerrarsesion.png" alt="Cerrar sesión" style="width: 35px; height: auto; margin-left: -10px;">
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false"><i class="mdi mdi-home"></i><span class="hide-menu">Inicio</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="gestionusuarios.php" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">Gestor de usuarios</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="citas.php" aria-expanded="false"><i class="mdi mdi-blur-linear"></i><span class="hide-menu">Reservas</span></a></li>
                        <li class="sidebar-item"><a class="sidebar-link waves-effect waves-dark sidebar-link" href="servicios.php" class="sidebar-link"><i class="mdi mdi-multiplication-box"></i><span class="hide-menu"> Servicios </span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="comentarios.php" aria-expanded="false"><i class="mdi mdi-relative-scale"></i><span class="hide-menu">Comentarios</span></a></li>
                    </ul>
                </nav>
            </div>
        </aside>

        <div class="page-wrapper" style="background-color: transparent; height: 100%;">
            <!-- Fondo de video -->
            <video class="hero_slide_background" autoplay muted loop width="100%" height="100%"
                src="https://i.makeagif.com/media/1-12-2018/WG7Djs.mp4" preload="metadata"  
                style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
                <!-- Añadir la pista de texto solo si es necesaria -->
                <track kind="metadata" label="cuepoints" data-removeondestroy="">
                Your browser does not support the video tag.
            </video>

            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center" style="margin-top: 20px;">
                        <h4 class="page-title" style="color: #f0f0f0; font-weight: bold;">User comments</h4>
                    </div>
                </div>
            </div>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-4">
                                    <i class="fas fa-comments"></i> Comentarios de los usuarios
                                </h4>

                                <div class="table-responsive">
                                    <table id="tablaComentarios" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Nombre</th>
                                                <th>Email</th>
                                                <th>Mensaje</th>
                                                <th>Fecha y Hora</th>
                                                <th>Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while($comentario = $resultado->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($comentario['nombre']); ?></td>
                                                    <td><?php echo htmlspecialchars($comentario['email']); ?></td>
                                                    <td><?php echo htmlspecialchars($comentario['mensaje']); ?></td>
                                                    <td><?php echo date('d M Y H:i', strtotime($comentario['fecha'])); ?></td>
                                                    <td>
                                                        <a href="controlador_eliminar_comentario.php?id=<?php echo $comentario['comentario_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar este comentario?');">
                                                            <i class="fas fa-trash-alt mr-1"></i> Eliminar
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Paginación -->
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-center">
                                        <?php for($i = 1; $i <= $total_paginas; $i++): ?>
                                            <li class="page-item <?php echo ($i == $pagina_actual) ? 'active' : ''; ?>">
                                                <a class="page-link" href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                                            </li>
                                        <?php endfor; ?>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
        <script src="dist/js/custom.min.js"></script>
        <script src="dist/js/sidebarmenu.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>

        <script>
        $(document).ready(function() {
            // Inicializar DataTable
            $('#tablaComentarios').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
                }
            });
        });
        </script>
    </div>
</body>

</html>