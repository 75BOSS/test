<?php
if (!empty($_POST['btnregistrar'])) {
    $nombre = $_POST['txtnombre'];
    $apellido = $_POST['txtapellido'];
    $email = $_POST['txtemail'];
    $telefono = $_POST['txttelefono'];
    $password = $_POST['txtpassword'];
    $rol = $_POST['txtrol'];

    if (!empty($nombre) && !empty($apellido) && !empty($email) && !empty($telefono) && !empty($password) && !empty($rol)) {
        $registrar = $conexion->query("INSERT INTO usuarios(nombre, apellido, email, telefono, password, rol) VALUES('$nombre', '$apellido', '$email', '$telefono', '$password', '$rol')");
        
        if ($registrar === TRUE) {
            echo "<script>
                    Swal.fire({
                        title: 'Felicidades',
                        text: 'Nuevo usuario registrado',
                        icon: 'success'
                    }).then(function() {
                        location.reload(); // Recargar la página después de cerrar la alerta
                    });
                  </script>";
           
        } else {
            echo "<div class='alert alert-danger'>Error al registrar el usuario: " . $conexion->error . "</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Debe llenar todos los campos</div>";
    }
}
?>
<script>
    window.history.replaceState(null, null, window.location.pathname);
</script>
