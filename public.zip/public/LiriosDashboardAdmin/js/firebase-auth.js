// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCuN5zSA8rMekut6Hwm6MbZHqU72LEGokk",
  authDomain: "proyectocriss-e423e.firebaseapp.com",
  projectId: "proyectocriss-e423e",
  storageBucket: "proyectocriss-e423e.appspot.com",
  messagingSenderId: "134989009875",
  appId: "1:134989009875:web:d3180fb747f43fd1645526",
  measurementId: "G-3GJEXC15V5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Function to add a user to Firestore
async function addUser(uid, name, surname, email, phone) {
  try {
    const docRef = await addDoc(collection(db, "users"), {
      uid: uid,
      name: name,
      surname: surname,
      email: email,
      phone: phone,
      timestamp: new Date()
    });
    console.log("User document written with ID: ", docRef.id);
    return true;
  } catch (error) {
    console.error("Error adding user document: ", error);
    return false;
  }
}

// Login function
async function loginUser(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    console.log("User logged in:", userCredential.user);
    return true;
  } catch (error) {
    console.error("Error logging in: ", error);
    return false;
  }
}

// Signup function
async function signupUser(email, password, name, surname, phone) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    console.log("User signed up:", userCredential.user);
    await addUser(userCredential.user.uid, name, surname, email, phone);
    return true;
  } catch (error) {
    console.error("Error signing up: ", error);
    return false;
  }
}

// Google Sign In function
async function signInWithGoogle() {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    console.log("Google sign in successful:", result.user);
    return true;
  } catch (error) {
    console.error("Error signing in with Google: ", error);
    return false;
  }
}

// Form submission handlers
document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('loginForm');
  const signupForm = document.getElementById('signupForm');
  const googleSignInBtn = document.getElementById('googleSignIn');

  loginForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    Swal.fire({
      title: 'Logging in...',
      text: 'Please wait while we log you in.',
      allowOutsideClick: false,
      showConfirmButton: false,
      willOpen: () => {
        Swal.showLoading();
      }
    });
    
    const success = await loginUser(email, password);
    
    if (success) {
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'You have been logged in successfully.',
        confirmButtonColor: '#3085d6'
      }).then(() => {
        window.location.href = 'index.html';
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'There was an error logging in. Please try again.',
        confirmButtonColor: '#d33'
      });
    }
  });

  signupForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const name = document.getElementById('signupName').value;
    const surname = document.getElementById('signupSurname').value;
    const phone = document.getElementById('signupPhone').value;
    
    Swal.fire({
      title: 'Signing up...',
      text: 'Please wait while we create your account.',
      allowOutsideClick: false,
      showConfirmButton: false,
      willOpen: () => {
        Swal.showLoading();
      }
    });
    
    const success = await signupUser(email, password, name, surname, phone);
    
    if (success) {
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Your account has been created successfully.',
        confirmButtonColor: '#3085d6'
      }).then(() => {
        window.location.href = 'index.html';
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'There was an error creating your account. Please try again.',
        confirmButtonColor: '#d33'
      });
    }
  });

  googleSignInBtn.addEventListener('click', async function() {
    Swal.fire({
      title: 'Signing in with Google...',
      text: 'Please wait while we log you in.',
      allowOutsideClick: false,
      showConfirmButton: false,
      willOpen: () => {
        Swal.showLoading();
      }
    });
    
    const success = await signInWithGoogle();
    
    if (success) {
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'You have been logged in with Google successfully.',
        confirmButtonColor: '#3085d6'
      }).then(() => {
        window.location.href = 'index.html';
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'There was an error logging in with Google. Please try again.',
        confirmButtonColor: '#d33'
      });
    }
  });
});