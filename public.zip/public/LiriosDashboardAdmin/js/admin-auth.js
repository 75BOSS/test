// Import Firebase functions
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore, getDoc, doc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCuN5zSA8rMekut6Hwm6MbZHqU72LEGokk",
  authDomain: "proyectocriss-e423e.firebaseapp.com",
  projectId: "proyectocriss-e423e",
  storageBucket: "proyectocriss-e423e.appspot.com",
  messagingSenderId: "134989009875",
  appId: "1:134989009875:web:d3180fb747f43fd1645526",
  measurementId: "G-3GJEXC15V5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Function to check if user is an admin
async function checkAdminStatus(user) {
  if (!user) {
    return false;
  }
  const userDoc = await getDoc(doc(db, 'users', user.uid));
  if (userDoc.exists()) {
    const userData = userDoc.data();
    return userData.role === 'admin';
  }
  return false;
}

// Function to show SweetAlert and redirect
function showLoginAlert() {
  Swal.fire({
    icon: 'warning',
    title: 'Acceso Denegado',
    text: 'Debes iniciar sesión para acceder a esta página.',
    confirmButtonText: 'Ir a Iniciar Sesión',
    allowOutsideClick: false
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = 'loginandregister.html';
    }
  });
}

// Main function to check authentication and admin status
function checkAuth() {
  onAuthStateChanged(auth, async (user) => {
    if (user) {
      const isAdmin = await checkAdminStatus(user);
      if (isAdmin) {
        console.log('Welcome, admin!');
        // The user is authenticated and is an admin
        // Show the admin content
        if (typeof window.showAdminContent === 'function') {
          window.showAdminContent();
        }
      } else {
        console.log('You are not authorized to view this page.');
        // Show error for non-admin users
        showLoginAlert();
      }
    } else {
      console.log('No user is signed in.');
      // Show login alert for unauthenticated users
      showLoginAlert();
    }
  });
}

// Call the checkAuth function when the page loads
window.onload = checkAuth;