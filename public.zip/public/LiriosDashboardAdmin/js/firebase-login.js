// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, fetchSignInMethodsForEmail, sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore, setDoc, getDoc, doc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCuN5zSA8rMekut6Hwm6MbZHqU72LEGokk",
  authDomain: "proyectocriss-e423e.firebaseapp.com",
  projectId: "proyectocriss-e423e",
  storageBucket: "proyectocriss-e423e.appspot.com",
  messagingSenderId: "134989009875",
  appId: "1:134989009875:web:d3180fb747f43fd1645526",
  measurementId: "G-3GJEXC15V5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Form validation function
function validateForm(email, password) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    Swal.fire({
      icon: 'error',
      title: 'Email inválido',
      text: 'Por favor, introduce un correo electrónico válido.'
    });
    return false;
  }
  if (password.length < 6) {
    Swal.fire({
      icon: 'error',
      title: 'Contraseña corta',
      text: 'La contraseña debe tener al menos 6 caracteres.'
    });
    return false;
  }
  return true;
}

// Password reset functionality
document.getElementById('forgot-password').addEventListener('click', async (e) => {
  e.preventDefault();
  
  const { value: email } = await Swal.fire({
    title: 'Recuperación de contraseña',
    input: 'email',
    inputLabel: 'Tu dirección de correo electrónico',
    inputPlaceholder: 'Ingresa tu correo electrónico',
    validationMessage: 'Por favor, ingresa un correo electrónico válido',
    showCancelButton: true,
    cancelButtonText: 'Cancelar',
    confirmButtonText: 'Enviar',
    allowOutsideClick: () => !Swal.isLoading()
  });

  if (email) {
    try {
      await sendPasswordResetEmail(auth, email);
      Swal.fire({
        icon: 'success',
        title: 'Correo enviado',
        text: 'Se ha enviado un enlace de recuperación a tu correo electrónico.'
      });
    } catch (error) {
      console.error('Error al enviar el correo de recuperación:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'No se pudo enviar el correo de recuperación. Por favor, intenta de nuevo más tarde.'
      });
    }
  }
});
// Modificamos la función de registro
document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;

  if (!validateForm(email, password)) {
    return;
  }

  try {
    // Check if email already exists
    const methods = await fetchSignInMethodsForEmail(auth, email);
    if (methods.length > 0) {
      throw new Error('Ya existe una cuenta asociada a este correo electronico.');
    }

    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Save user data
    await setDoc(doc(db, 'users', user.uid), { name: user.displayName, email: email, role: 'user' });

    // Reset the form
    document.getElementById('register-form').reset();

    // Guardamos la posición actual de scroll
    const scrollPosition = window.pageYOffset;

    Swal.fire({
      icon: 'success',
      title: 'Registro exitoso',
      text: 'Usuario registrado exitosamente',
      showConfirmButton: true
    }).then(() => { 
      // Restauramos la posición de scroll después de cerrar el cuadro de diálogo
      window.scrollTo(0, scrollPosition);     
    });
   
  } catch (error) {
    console.error('Error durante el registro:', error);
    Swal.fire({ icon: 'error', title: 'Error de registro', text: error.message });
  }
});


// Login event listener
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Get user role from Firestore
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (userDoc.exists()) {
      const userData = userDoc.data();
      if (userData.role === 'admin') {
        window.location.href = 'admindashbo.html'; // Redirect to admin dashboard
      } else {
        window.location.href = 'https://www.google.com'; // Redirect to user dashboard
      }
    }
  } catch (error) {
    console.error('Error during login:', error);
    Swal.fire({
      icon: 'error',
      title: 'Error de inicio de sesión',
      text: error.message
    });
  }
});

// Google Sign In function
window.googleSignIn = async function () {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    // Save user data if it doesn't exist
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (!userDoc.exists()) {
      await setDoc(doc(db, 'users', user.uid), {
        name: user.displayName,
        email: user.email,
        role: 'user'
      });
    }

    Swal.fire({
      icon: 'success',
      title: 'Inicio de sesión exitoso',
      text: 'Has iniciado sesión con Google correctamente'
    }).then(() => {
      window.location.href = 'https://www.google.com';  // Redirect after successful login
    });
  } catch (error) {
    console.error('Error during Google Sign In:', error);
    Swal.fire({
      icon: 'error',
      title: 'Error de autenticación',
      text: 'Error en la autenticación con Google: ' + error.message
    });
  }
}
