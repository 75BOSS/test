<?php
session_start();
session_destroy();
header("Location: ../LiriosDashboardAdmin/loginandregister.html");
exit;
?>