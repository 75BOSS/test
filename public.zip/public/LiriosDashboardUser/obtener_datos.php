<?php
session_start();

// Verificar si el archivo de conexión existe
if (!file_exists('conexion.php')) {
    die(json_encode(['error' => "El archivo de conexión no existe."]));
}

include 'conexion.php';

// Verificar la conexión
if (!$conexion) {
    die(json_encode(['error' => "Error de conexión: " . mysqli_connect_error()]));
}

// Verificar la sesión
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'user') {
    die(json_encode(['error' => "Sesión no válida."]));
}

// Verificar que las variables de sesión necesarias estén configuradas
if (!isset($_SESSION['id']) || !isset($_SESSION['nombre']) || !isset($_SESSION['usuario'])) {
    die(json_encode(['error' => "Variables de sesión no configuradas correctamente."]));
}

$id_usuario = $_SESSION['id'];
$nombre_usuario = $_SESSION['nombre'];
$email_usuario = $_SESSION['usuario'];

// Obtener citas próximas del usuario
$sql_citas = "SELECT Citas.*, Servicios.nombre AS servicio_nombre FROM Citas 
              INNER JOIN Servicios ON Citas.servicio_id = Servicios.servicio_id 
              WHERE usuario_id = ? AND fecha >= CURDATE() 
              ORDER BY fecha ASC";

$citas = [];
if ($stmt = $conexion->prepare($sql_citas)) {
    $stmt->bind_param("i", $id_usuario);
    if ($stmt->execute()) {
        $resultado_citas = $stmt->get_result();
        while ($row = $resultado_citas->fetch_assoc()) {
            $citas[] = $row;
        }
    } else {
        die(json_encode(['error' => "Error ejecutando la consulta de citas: " . $stmt->error]));
    }
} else {
    die(json_encode(['error' => "Error preparando la consulta de citas: " . $conexion->error]));
}

// Obtener servicios disponibles
$sql_servicios = "SELECT * FROM Servicios";
$resultado_servicios = $conexion->query($sql_servicios);

$servicios = [];
if ($resultado_servicios) {
    while ($row = $resultado_servicios->fetch_assoc()) {
        $servicios[] = $row;
    }
} else {
    die(json_encode(['error' => "Error en la consulta de servicios: " . $conexion->error]));
}

// Devolver los datos como JSON
echo json_encode([
    'usuario' => [
        'id' => $id_usuario,
        'nombre' => $nombre_usuario,
        'email' => $email_usuario
    ],
    'citas' => $citas,
    'servicios' => $servicios
]);
?>