<?php
session_start();
include("conexion_be.php");

if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'user'){
    echo '
        <script>
        alert("Acceso no autorizado. Debes iniciar sesión como usuario.");
        window.location = "loginandregister.php";
        </script>
    ';
    session_destroy();
    die();
}

// Aquí puedes agregar la lógica para obtener los datos del usuario
$id_usuario = $_SESSION['id'];
$nombre_usuario = $_SESSION['nombre'];
$email_usuario = $_SESSION['usuario'];  // Asumiendo que guardamos el email como 'usuario' en la sesión
// Add this near the top of your PHP section, after the database connection is established
$query_servicios = "SELECT * FROM servicios"; // Adjust the table name if needed

$resultado_servicios = $conexion->query($query_servicios);

if (!$resultado_servicios) {
    die("Error en la consulta: " . $conexion->error);
}
if ($resultado_servicios->num_rows > 0) {
    while ($servicio = $resultado_servicios->fetch_assoc()) {
        // Your existing code to display each service
    }
} else {
    echo "<p>No hay servicios disponibles en este momento.</p>";
}

$conexion->close();
?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/minilogo.jpeg">
    <title>LC - Servicios</title>
    
    <link href="dist/css/style.min.css" rel="stylesheet">
     
</head>

<body>
    
      
    <div id="main-wrapper">
        
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                  
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                   
                    <a class="navbar-brand" href="index.php">
                       
                        <b class="logo-icon p-l-10">
                           
                        <img src="assets/images/logo1.jpg" alt="homepage" class="light-logo logo-style" 
                        style="margin-top: 5px; width: 65px; height: auto; border-radius: 15px;" />
                          
                       </b>
                       
                       <span class="logo-text">
                            
                       <img src="assets/images/logo3.png" alt="homepage" class="light-logo" width="150"
                       style="margin-top: 5px; width: 147px; height: auto; border-radius: 15px;" />
                           
                       </span>
                        
                    </a>
                    
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
                
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                        
                    </ul>

                    <ul style="margin-top: 15px;" >
                            <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="logout.php" 
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/cerrarsesion.png" alt="Cerrar sesión" 
                                    style="width: 35px; height: auto; margin-left: -10px;">
                            </a>                                
                            </li>
                        </ul>
                    
                    
                </div>
            </nav>
        </header>
        
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="indexuser.php" aria-expanded="false"><i class="mdi mdi-home"></i><span class="hide-menu">Inicio</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="citasuser.php" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">Mis Reservas</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="serviciosuser.php" aria-expanded="false"><i class="mdi mdi-blur-linear"></i><span class="hide-menu">Servicios Disponibles</span></a></li>
                        </li> 
                    </ul>
                </nav>
            </div>
            
        </aside>
        
        <div class="page-wrapper" style="background-color: transparent ;" >
        <video class="hero_slide_background" autoplay muted loop width="100%" height="100%"
            src="https://i.makeagif.com/media/1-12-2018/WG7Djs.mp4" preload="metadata"  
            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
            <!-- Añadir la pista de texto solo si es necesaria -->
            <track kind="metadata" label="cuepoints" data-removeondestroy="">
            Your browser does not support the video tag.
        </video>
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb" style="margin-top: 15px;">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title" style="color: #f0f0f0; font-weight: bold;">Dashboard</h4>
                    </div>
                </div>
            </div>

            
            <div class="container-fluid" style="position: relative; overflow: hidden; height: 88vh;" >
                            <div class="row el-element-overlay">
                                <?php
                                $resultado_servicios->data_seek(0);
                                while ($servicio = $resultado_servicios->fetch_assoc()) {
                                    ?>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="card">
                                            <div class="el-card-item">
                                                <div class="el-card-avatar el-overlay-1">
                                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($servicio['imagen']); ?>" alt="<?php echo htmlspecialchars($servicio['nombre']); ?>">
                                                    
                                                </div>
                                                <div class="el-card-content">
                                                    <h4 class="m-b-0"><?php echo $servicio['nombre']; ?></h4>
                                                    <span class="text-muted">Precio: $<?php echo $servicio['precio']; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                }
                                ?>
                                
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                 <div class="modal fade" id="imageModal<?php echo $servicio['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel<?php echo $servicio['id']; ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="imageModalLabel<?php echo $servicio['id']; ?>"><?php echo htmlspecialchars($servicio['nombre']); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($servicio['imagen']); ?>" class="img-fluid" alt="<?php echo htmlspecialchars($servicio['nombre']); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
            
        </div>
       
    </div>
    
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>


</body>

</html>