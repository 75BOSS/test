<?php

include 'conexion.php';
include("controlador_registrar_cita.php");

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'user') {
    header("Location: ../LiriosDasboardAdmin/loginandregister.php");
    exit();
}

$id_usuario = $_SESSION['id'];
$nombre_usuario = $_SESSION['nombre'];
$email_usuario = $_SESSION['usuario'];

// Obtener las citas del usuario
$sql_citas = "SELECT c.*, s.nombre AS servicio_nombre, s.precio 
              FROM citas c
              INNER JOIN servicios s ON c.servicio_id = s.servicio_id 
              WHERE c.usuario_id = ? AND c.fecha >= CURDATE() 
              ORDER BY c.fecha ASC";
$stmt = $conexion->prepare($sql_citas);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado_citas = $stmt->get_result();

// Obtener los servicios disponibles
$sql_servicios = "SELECT * FROM servicios";
$resultado_servicios = $conexion->query($sql_servicios);
?>

<!DOCTYPE html>
<html dir="ltr" lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Dashboard de usuario de BeautyGlow Cosmetología">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/minilogo.jpeg">
    <title>LcFerreteria - Dashboard de Usuario</title>
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="assets/libs/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet" />
    <link href="assets/extra-libs/calendar/calendar.css" rel="stylesheet" />
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="dist/css/userstyles.css" rel="stylesheet">
</head>
<body>
    <div id="main-wrapper">
        <!-- Header y Sidebar (omitiendo para simplificar) -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- Logo -->
                    <a class="navbar-brand" >
                        <b class="logo-icon p-l-10">
                           
                        <img src="assets/images/logo1.jpg" alt="homepage" class="light-logo logo-style" 
                        style="margin-top: 5px; width: 65px; height: auto; border-radius: 15px;" />
                          
                       </b>
                       
                       <span class="logo-text">
                            
                       <img src="assets/images/logo3.png" alt="homepage" class="light-logo" width="150"
                        style="margin-top: 5px; width: 147px; height: auto; border-radius: 15px;" />
                           
                       </span>
                    </a>
                </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block">
                            <a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar">
                                <i class="mdi mdi-menu font-24"></i>
                            </a>
                        </li>
                    </ul>

                    <ul style="margin-top: 15px;" >
                            <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="logout.php" 
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/cerrarsesion.png" alt="Cerrar sesión" 
                                    style="width: 35px; height: auto; margin-left: -10px;">
                            </a>                                
                            </li>
                        </ul>

                    
                </div>
            </nav>
        </header>
        
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                        
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="indexuser.php" aria-expanded="false"><i class="mdi mdi-home"></i><span class="hide-menu">Inicio</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="citasuser.php" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">Mis Reservas</span></a></li>
                            <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="serviciosuser.php" aria-expanded="false"><i class="mdi mdi-blur-linear"></i><span class="hide-menu">Servicios Disponibles</span></a></li>
                                                
                    </ul>
                </nav>
            </div>
        </aside>


        <div class="page-wrapper" style="background-color: transparent;">
            <video class="hero_slide_background" autoplay muted loop width="100%" height="100%"
                src="https://i.makeagif.com/media/1-12-2018/WG7Djs.mp4" preload="metadata"  
                style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
                <track kind="metadata" label="cuepoints" data-removeondestroy="">
                Your browser does not support the video tag.
            </video>
            
            <div class="container-fluid" style="background-color: rgba(255, 255, 255, 0.5);">
                <div class="row">
                
                    <div class="calendar-wrapper">
                        <div class="calendar-container">
                            <div class="today" style="background-image: url('https://cdn.mos.cms.futurecdn.net/xaycNDmeyxpHDrPqU6LmaD-650-80.jpg.webp');">
                                <span class="today-label">HOY</span>
                                <span class="today-date" id="todayDate"></span>
                                <span class="today-month" id="todayMonth"></span>
                            </div>
                            <div class="calendar">
                                <div class="nav-buttons">
                                    <button class="nav-button" id="prevMonth">&lt;</button>
                                    <h2 id="currentMonth"></h2>
                                    <button class="nav-button" id="nextMonth">&gt;</button>
                                </div>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Dom</th>
                                            <th>Lun</th>
                                            <th>Mar</th>
                                            <th>Mié</th>
                                            <th>Jue</th>
                                            <th>Vie</th>
                                            <th>Sáb</th>
                                        </tr>
                                    </thead>
                                    <tbody id="calendarBody"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal para reservar cita -->
                <div id="dateModal" class="modal">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Reservar Cita</h2>
                            <span class="close" id="closeModal">&times;</span>
                        </div>
                        <div class="modal-body">
                            <form id="dateForm" method="POST" action="controlador_registrar_cita.php">
                                <label for="userName">Nombre de Usuario:</label>
                                <input type="text" id="userName" name="userName" value="<?php echo $nombre_usuario; ?>" readonly>

                                <label for="selectedDate">Fecha:</label>
                                <input type="text" id="selectedDate" name="selectedDate" readonly>

                                <label for="selectedTime">Hora:</label>
                                <select id="selectedTime" name="selectedTime" required>
                                    <option value="10:00">10:00 AM</option>
                                    <option value="11:00">11:00 AM</option>
                                    <option value="12:00">12:00 PM</option>
                                    <option value="13:00">01:00 PM</option>
                                    <option value="14:00">02:00 PM</option>
                                    <option value="15:00">03:00 PM</option>
                                    <option value="16:00">04:00 PM</option>
                                    <option value="17:00">05:00 PM</option>
                                </select>

                                <label for="service">Servicio:</label>
                                <select id="service" name="service" required>
                                    <?php
                                    $resultado_servicios->data_seek(0);
                                    while ($servicio = $resultado_servicios->fetch_assoc()) {
                                        echo "<option value='" . $servicio['servicio_id'] . "' data-precio='" . $servicio['precio'] . "'>" . $servicio['nombre'] . "</option>";
                                    }
                                    ?>
                                </select>

                                <label for="estado">Estado:</label>
                                <select id="estado" name="estado" required>
                                    <option value="pendiente">Pendiente</option>
                                    <option value="confirmado">Confirmado</option>
                                    <option value="finalizado">Finalizado</option>
                                </select>

                                <label for="price">Precio:</label>
                                <input type="text" id="price" name="price" readonly>

                                <label for="notas">Notas:</label>
                                <textarea id="notas" name="notas"></textarea>

                                <div class="selected-date-time">
                                    <p>Fecha y hora seleccionadas:</p>
                                    <p id="selectedDateTime"></p>
                                </div>

                                <input type="hidden" id="userId" name="userId" value="<?php echo $id_usuario; ?>">
                                <input type="submit" name="btnregistrar" value="Reservar">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="dist/js/waves.js"></script>
    <script src="dist/js/sidebarmenu.js"></script>
    <script src="dist/js/custom.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Script del Calendario -->
    <script>
        const today = new Date();
        let currentMonth = today.getMonth();
        let currentYear = today.getFullYear();
        const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

        function updateCalendar() {
            const firstDay = new Date(currentYear, currentMonth, 1);
            const lastDay = new Date(currentYear, currentMonth + 1, 0);

            document.getElementById('currentMonth').textContent = `${monthNames[currentMonth]} ${currentYear}`;

            const calendarBody = document.getElementById('calendarBody');
            calendarBody.innerHTML = '';

            let date = 1;
            for (let i = 0; i < 6; i++) {
                const row = document.createElement('tr');
                for (let j = 0; j < 7; j++) {
                    if (i === 0 && j < firstDay.getDay()) {
                        const cell = document.createElement('td');
                        cell.classList.add('empty');
                        row.appendChild(cell);
                    } else if (date > lastDay.getDate()) {
                        break;
                    } else {
                        const cell = document.createElement('td');
                        cell.textContent = date;
                        if (date === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear()) {
                            cell.classList.add('today-highlight');
                        }
                        cell.addEventListener('click', (function(selectedDate) {
                            return function() {
                                openModal(selectedDate);
                            };
                        })(date));
                        row.appendChild(cell);
                        date++;
                    }
                }
                calendarBody.appendChild(row);
            }
        }

        // Actualizar el calendario al cargar la página
        document.addEventListener('DOMContentLoaded', function() {
            updateCalendar();
        });

        // Navegación entre meses
        document.getElementById('prevMonth').addEventListener('click', () => {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            updateCalendar();
        });

        document.getElementById('nextMonth').addEventListener('click', () => {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            updateCalendar();
        });

        // Abrir el modal al seleccionar una fecha
        function openModal(date) {
            document.getElementById("selectedDate").value = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
            document.getElementById("selectedDateTime").textContent = `Fecha: ${date}/${currentMonth + 1}/${currentYear}`;
            document.getElementById("dateModal").style.display = "block";
        }

        // Cerrar el modal
        function closeModal() {
            document.getElementById("dateModal").style.display = "none";
        }

        // Event listeners para cerrar el modal
        document.getElementById("closeModal").addEventListener('click', closeModal);
        window.addEventListener('click', function(event) {
            const modal = document.getElementById("dateModal");
            if (event.target === modal) {
                modal.style.display = "none";
            }
        });

        // Actualizar el precio al cambiar el servicio
        document.getElementById("service").addEventListener("change", function() {
            const selectedService = this.options[this.selectedIndex];
            const price = selectedService.getAttribute('data-precio');
            document.getElementById("price").value = "$" + price;
        });

        // Inicializar el precio con el primer servicio
        window.addEventListener('load', function() {
            const firstService = document.getElementById("service").options[0];
            if (firstService) {
                const initialPrice = firstService.getAttribute('data-precio');
                document.getElementById("price").value = "$" + initialPrice;
            }
        });
    </script>

<script>
    // Función para obtener parámetros de la URL
    function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }

    // Verificar si hay mensajes en la URL
    window.onload = function() {
        var success = getUrlParameter('success');
        var error = getUrlParameter('error');
        var message = getUrlParameter('message');

        if (success === '1') {
            Swal.fire({
                icon: 'success',
                title: '¡Éxito!',
                text: message,
                confirmButtonColor: '#3085d6'
            });
        } else if (error === '1') {
            Swal.fire({
                icon: 'error',
                title: '¡Error!',
                text: message,
                confirmButtonColor: '#d33'
            });
        }
    }
</script>

</body>
</html>