<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['id'])) {
    header('Location: ../LiriosDasboardAdmin/loginandregister.php');
    exit();
}

$id_usuario = $_SESSION['id'];

if (!empty($_POST['btnregistrar'])) {
    $servicio_id = intval($_POST['service']);
    $fecha = $_POST['selectedDate'];
    $hora = $_POST['selectedTime'];
    $estado = 'Pendiente';
    $notas = $_POST['notas'];

    if (!empty($servicio_id) && !empty($fecha) && !empty($hora)) {
        $fecha_hora = $fecha . ' ' . $hora . ':00';

        $stmt = $conexion->prepare("INSERT INTO citas(usuario_id, servicio_id, fecha, hora, estado, notas) VALUES(?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            header('Location: citasuser.php?error=1&message=' . urlencode('Error en la preparación de la inserción'));
            exit();
        }
        
        $stmt->bind_param('iissss', $id_usuario, $servicio_id, $fecha, $hora, $estado, $notas);
        
        if ($stmt->execute()) {
            header('Location: citasuser.php?success=1&message=' . urlencode('Su cita ha sido registrada y está pendiente de confirmación'));
        } else {
            header('Location: citasuser.php?error=1&message=' . urlencode('Error al registrar la cita: ' . $stmt->error));
        }
        $stmt->close();
    } else {
        header('Location: citasuser.php?error=1&message=' . urlencode('Debe seleccionar un servicio, una fecha y una hora para la cita'));
    }
    exit();
}
?>