<?php
session_start();
include("conexion_be.php");

if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'user'){
    echo '
        <script>
        alert("Acceso no autorizado. Debes iniciar sesión como usuario.");
        window.location = "loginandregister.php";
        </script>
    ';
    session_destroy();
    die();
}

// Aquí puedes agregar la lógica para obtener los datos del usuario
$id_usuario = $_SESSION['id'];
$nombre_usuario = $_SESSION['nombre'];
$email_usuario = $_SESSION['usuario'];  // Asumiendo que guardamos el email como 'usuario' en la sesión
// Add this near the top of your PHP section, after the database connection is established
$query_servicios = "SELECT * FROM servicios"; // Adjust the table name if needed

$resultado_servicios = $conexion->query($query_servicios);

if (!$resultado_servicios) {
    die("Error en la consulta: " . $conexion->error);
}
if ($resultado_servicios->num_rows > 0) {
    while ($servicio = $resultado_servicios->fetch_assoc()) {
        // Your existing code to display each service
    }
} else {
    echo "<p>No hay servicios disponibles en este momento.</p>";
}

$conexion->close();
?>

<!DOCTYPE html>
<html dir="ltr" lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Dashboard de usuario de BeautyGlow Cosmetología">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>BeautyGlow - Dashboard de Usuario</title>
    <link href="assets/libs/magnific-popup/dist/magnific-popup.css" rel="stylesheet">
    <link href="dist/css/style.min.css" rel="stylesheet">
</head>

<body>
    <div id="main-wrapper">
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- Logo -->
                    <a class="navbar-brand" href="userdashboard.php">
                        <b class="logo-icon p-l-10">
                            <img src="assets/images/logo-icon.png" alt="homepage" class="light-logo" />
                        </b>
                        <span class="logo-text">
                            <img src="assets/images/logo-text.png" alt="homepage" class="light-logo" />
                        </span>
                    </a>
                </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block">
                            <a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar">
                                <i class="mdi mdi-menu font-24"></i>
                            </a>
                        </li>
                    </ul>
                    <ul class="navbar-nav float-right">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/users/1.jpg" alt="user" class="rounded-circle" width="31">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated shadow-lg">
                                <div class="user-header bg-primary p-3 text-white">
                                    <img src="assets/images/users/1.jpg" alt="User Avatar" class="img-fluid rounded-circle mb-2" style="width: 80px;">
                                    <h6 class="mb-0"><?php echo $nombre_usuario; ?></h6>
                                    <small><?php echo $email_usuario; ?></small>
                                </div>
                                <div class="user-body p-3">
                                    <a class="dropdown-item d-flex align-items-center mb-2" href="perfil_usuario.php">
                                        <i class="fas fa-user-circle mr-2 text-primary"></i> Ver Perfil
                                    </a>
                                    <a class="dropdown-item d-flex align-items-center mb-2" href="configuracion_usuario.php">
                                        <i class="fas fa-cog mr-2 text-secondary"></i> Configuración
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item d-flex align-items-center text-danger" href="logout.php">
                                        <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
                                    </a>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="userdashboard.php" aria-expanded="false">
                                <i class="mdi mdi-home"></i><span class="hide-menu">Inicio</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="mis_citas.php" aria-expanded="false">
                                <i class="mdi mdi-calendar-check"></i><span class="hide-menu">Mis Citas</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="servicios_disponibles.php" aria-expanded="false">
                                <i class="mdi mdi-multiplication-box"></i><span class="hide-menu">Servicios Disponibles</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="mis_comentarios.php" aria-expanded="false">
                                <i class="mdi mdi-comment-text"></i><span class="hide-menu">Mis Comentarios</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        
        <div class="page-wrapper" style="background-color: transparent;">
        <video class="hero_slide_background" autoplay muted loop width="100%" height="100%"
                src="https://videos.pexels.com/video-files/3741677/3741677-hd_1920_1080_25fps.mp4" preload="metadata" style="position: absolute; top: 0;left: 0; width: 100%;height: 100%;object-fit: cover;z-index: -1;">
                <track kind="metadata" label="cuepoints" data-removeondestroy="">
                Your browser does not support the video tag.
            </video>
            <div class="container-fluid" style="background-color: rgba(255, 255, 255, 0.5);;" >
                            <div class="row el-element-overlay">
                                <?php
                                $resultado_servicios->data_seek(0);
                                while ($servicio = $resultado_servicios->fetch_assoc()) {
                                    ?>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="card">
                                            <div class="el-card-item">
                                                <div class="el-card-avatar el-overlay-1">
                                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($servicio['imagen']); ?>" alt="<?php echo htmlspecialchars($servicio['nombre']); ?>">
                                                    
                                                </div>
                                                <div class="el-card-content">
                                                    <h4 class="m-b-0"><?php echo $servicio['nombre']; ?></h4>
                                                    <span class="text-muted">Precio: $<?php echo $servicio['precio']; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                }
                                ?>
                                
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                 <div class="modal fade" id="imageModal<?php echo $servicio['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel<?php echo $servicio['id']; ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="imageModalLabel<?php echo $servicio['id']; ?>"><?php echo htmlspecialchars($servicio['nombre']); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($servicio['imagen']); ?>" class="img-fluid" alt="<?php echo htmlspecialchars($servicio['nombre']); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
        
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <script src="dist/js/waves.js"></script>
    <script src="dist/js/sidebarmenu.js"></script>
    <script src="dist/js/custom.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        
        $(document).ready(function() {
            $('.btn-close, .close').on('click', function() {
                var $modal = $(this).closest('.modal');
                $modal.modal('hide');
                $('body').removeClass('modal-open');
                $('.modal-backdrop').remove();
            });
        });
        </script>
</body>

</html>