<?php
session_start();
include 'conexion.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'user') {
    echo json_encode(['success' => false, 'message' => 'Usuario no autorizado']);
    exit;
}

// Verificar que todos los campos necesarios estén presentes
$required_fields = ['userId', 'service', 'selectedDate', 'selectedTime', 'estado'];
foreach ($required_fields as $field) {
    if (!isset($_POST[$field]) || empty($_POST[$field])) {
        echo json_encode(['success' => false, 'message' => "Campo requerido faltante: $field"]);
        exit;
    }
}

// Obtener los datos del formulario
$usuario_id = $_POST['userId'];
$servicio_id = $_POST['service'];
$fecha = $_POST['selectedDate'];
$hora = $_POST['selectedTime'];
$estado = $_POST['estado'];

// La fecha ya viene en formato Y-m-d, no es necesario convertirla
$fecha_formateada = $fecha;

// Combinar fecha y hora
$fecha_hora = $fecha_formateada . ' ' . $hora . ':00';

// Preparar la consulta SQL
$sql = "INSERT INTO Citas (usuario_id, servicio_id, fecha, estado, hora) VALUES (?, ?, ?, ?, ?)";
$stmt = $conexion->prepare($sql);

if ($stmt === false) {
    echo json_encode(['success' => false, 'message' => 'Error al preparar la consulta: ' . $conexion->error]);
    exit;
}

$stmt->bind_param("iisss", $usuario_id, $servicio_id, $fecha_hora, $estado, $hora);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al ejecutar la consulta: ' . $stmt->error]);
}

$stmt->close();
$conexion->close();
?>